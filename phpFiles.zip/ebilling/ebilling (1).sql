-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2017 at 03:58 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ebilling`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `cname` varchar(20) DEFAULT NULL,
  `phno` int(10) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `pass` varchar(20) DEFAULT NULL,
  `cuname` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cid`, `cname`, `phno`, `email`, `pass`, `cuname`) VALUES
(1, 'abc', 0, 'aaa@t.com', 'abc', 'abc'),
(2, 'priya', 2147483647, 'priyakavre@ymail.com', 'piyu', 'piyu'),
(3, 'devi', 2147483647, 'd@g.com', 'devi', 'devi'),
(4, 'mandeep', 996931528, 'mandeep.vratesh@gmai', 'mandeep', 'mandeep');

-- --------------------------------------------------------

--
-- Table structure for table `discount`
--

CREATE TABLE IF NOT EXISTS `discount` (
  `discountid` int(10) NOT NULL AUTO_INCREMENT,
  `discount` text,
  PRIMARY KEY (`discountid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `discount`
--

INSERT INTO `discount` (`discountid`, `discount`) VALUES
(1, 'buy 1 get 1 free'),
(2, 'flat 50% off ');

-- --------------------------------------------------------

--
-- Table structure for table `offer`
--

CREATE TABLE IF NOT EXISTS `offer` (
  `offerid` int(10) NOT NULL AUTO_INCREMENT,
  `offer` text,
  PRIMARY KEY (`offerid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `offer`
--

INSERT INTO `offer` (`offerid`, `offer`) VALUES
(4, 'buy 1 get 1 free on vimbar'),
(5, '50%off on mobiles');

-- --------------------------------------------------------

--
-- Table structure for table `prodcount`
--

CREATE TABLE IF NOT EXISTS `prodcount` (
  `pid` int(10) DEFAULT NULL,
  `count` int(10) DEFAULT NULL,
  KEY `fk` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `productlist`
--

CREATE TABLE IF NOT EXISTS `productlist` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `pname` varchar(20) DEFAULT NULL,
  `price` float NOT NULL,
  `floor` varchar(10) NOT NULL,
  `side` varchar(10) NOT NULL,
  `section` varchar(10) NOT NULL,
  `weight` int(10) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `pname` (`pname`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `productlist`
--

INSERT INTO `productlist` (`pid`, `pname`, `price`, `floor`, `side`, `section`, `weight`) VALUES
(1, 'ParleG', 20, 'ground', 'left', 'biscuit', NULL),
(2, 'lux', 25, '1st', 'left', 'soap', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE IF NOT EXISTS `purchases` (
  `billid` varchar(50) NOT NULL,
  `pid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `purchaseid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL,
  `count` int(11) NOT NULL,
  PRIMARY KEY (`purchaseid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`billid`, `pid`, `cid`, `purchaseid`, `timestamp`, `count`) VALUES
('100', 1, 1, 1, '0000-00-00 00:00:00', 0),
('duwgk', 3, 4, 67, '2017-02-26 04:34:46', 0),
('hggkhg', 557, 68, 878, '2017-02-27 09:44:06', 0);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `prodcount`
--
ALTER TABLE `prodcount`
  ADD CONSTRAINT `fk` FOREIGN KEY (`pid`) REFERENCES `productlist` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
