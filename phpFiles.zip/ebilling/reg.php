<html>
<head>
</head>

<body>
<form action="registration.php" method="POST">  
 <input type="text" placeholder="name" name="name" maxlength="100">
<br>
<br>
<input type="text" placeholder="phno" name="phno" maxlength="100">
<br>
<br>
<input type="text" placeholder="email" name="email" maxlength="100">
<br>
<br>
<input type="text" placeholder="pass" name="pass" maxlength="100">
<br>
<br>
<input type="text" placeholder="cpass" name="cpass" maxlength="100">
<br>
<br>
<input type="text" placeholder="username" name="uname" maxlength="100">
<br>
<br>

<input type="submit" name="submit" value="submit">
 
</form>
</body>


</html>