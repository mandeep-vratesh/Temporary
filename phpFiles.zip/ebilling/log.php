<html>
<head>
</head>

<body>
<form action="login.php" method="POST">
name<input type="text" name="uname" maxlength="30">
<br>
<br>
Pass <input type="password" name="pass"  maxlength="30">
<br>
<br>

<input type="submit" value="Submit">

</form>
</body>


</html>
