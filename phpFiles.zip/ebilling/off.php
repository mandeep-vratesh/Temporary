<html>
<head>
</head>

<body>
<form action="offer.php" method="POST">
 <input type="text" placeholder="type here" name="oname" maxlength="100">
<br>
<br>

<input type="submit" name="submit" value="Add Offer">

</form>
</body>


</html>
