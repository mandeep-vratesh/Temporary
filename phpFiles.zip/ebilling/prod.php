<html>
<head>
</head>

<body>
<form action="product.php" method="POST">
Product name: <input type="text" name="pname" maxlength="30">
<br>
<br>
Product price: <input type="text" name="price"  maxlength="30">
<br>
<br>
Product location (floor no): <input type="text" name="floor"  maxlength="30">
<br>
<br>
left/right : <input type="text" name="side"  maxlength="30">
<br>
<br>
Product section: <input type="text" name="section" maxlength="30">
<br>
<br>
<input type="button" value="Submit">

</form>
</body>


</html>
