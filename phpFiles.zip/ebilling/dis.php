<html>
<head>
</head>

<body>
<form action="discount.php" method="POST">  
 <input type="text" placeholder="type here" name="dname" maxlength="100">
<br>
<br>

<input type="submit" name="submit" value="Add Discount">
 
</form>
</body>


</html>
